package com.unitec.crawler.http.service.intf;

import java.net.URI;

public interface SpiderService {
	
	public void initiateURICrawling(URI uri,Integer depth) throws Exception;

}
