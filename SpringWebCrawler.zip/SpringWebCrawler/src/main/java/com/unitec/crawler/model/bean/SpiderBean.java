/**
 * 
 */
package com.unitec.crawler.model.bean;

import java.net.URI;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

/**
 * @author JOEL
 *
 */
public class SpiderBean {

	private List<URI> pagesToVisit;
	private Set<URI> pagesVisited;
	
	public SpiderBean() {
		 pagesToVisit= new LinkedList<URI>();
		 pagesVisited = new HashSet<URI>();
	}
	public List<URI> getPagesToVisit() {
		return pagesToVisit;
	}
	public void setPagesToVisit(List<URI> pagesToVisit) {
		this.pagesToVisit = pagesToVisit;
	}
	public Set<URI> getPagesVisited() {
		return pagesVisited;
	}
	public void setPagesVisited(Set<URI> pagesVisited) {
		this.pagesVisited = pagesVisited;
	}
	
	
	
	
	
/*	
	public Spider() {
		 pagesToVisit= new LinkedList<String>();
		 pagesVisited = new HashSet<String>();
	}
	
	public List<String> getPagesToVisit() {
		return pagesToVisit;
	}
	public void setPagesToVisit(List<String> pagesToVisit) {
		this.pagesToVisit = pagesToVisit;
	}
	public Set<String> getPagesVisited() {
		return pagesVisited;
	}
	public void setPagesVisited(Set<String> pagesVisited) {
		this.pagesVisited = pagesVisited;
	} 
	
	public String nextUrl()
	{
		String nextUrl;
		do
		{
			nextUrl = this.getPagesToVisit().remove(0);
		} while(this.getPagesVisited().contains(nextUrl));
		this.getPagesVisited().add(nextUrl);
		return nextUrl;
	}*/
}
