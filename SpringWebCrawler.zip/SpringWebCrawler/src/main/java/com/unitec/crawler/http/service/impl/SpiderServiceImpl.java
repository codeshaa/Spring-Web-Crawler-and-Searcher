/**
 * 
 */
package com.unitec.crawler.http.service.impl;

import java.io.File;
import java.net.URI;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.unitec.crawler.http.service.intf.HttpClientService;
import com.unitec.crawler.http.service.intf.HttpParserService;
import com.unitec.crawler.http.service.intf.SpiderService;
import com.unitec.crawler.model.bean.SpiderBean;

/**
 * @author JOEL
 *
 */
@Service
public class SpiderServiceImpl implements SpiderService{
	
	private static Logger logger = LoggerFactory
			.getLogger(SpiderServiceImpl.class);
	public static SpiderBean siteTree= new SpiderBean();
	public static int currentDepth;
	public static String URI_HOST;
	public static String URI_HOST_KEY;
	@Autowired
	public HttpParserService parserService;
	@Autowired
	public HttpClientService clientService;

	/**
	 * @author JOEL,Sharun
	 *
	 */
	@Override
	public void initiateURICrawling(URI uri,Integer depth) throws Exception {
		
		try {
			URI_HOST = uri.getHost();
			URI_HOST_KEY = uri.getHost().substring(4);
		
			//Delete previous Lucene Data
			deleteIndeingData();
			
			//Start Crawl Operation
			long crawlStartTime = System.currentTimeMillis();
			crawl(uri, depth);
			long crawlEndTime = System.currentTimeMillis();

			logger.info("No of Visited links"+ siteTree.getPagesVisited().size());
			logger.info("No of Unvisited links" + siteTree.getPagesToVisit().size());
			logger.info("Time taken"+ (float) (crawlEndTime - crawlStartTime) / 1000 + "sec");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;		
			}
	}

	private void crawl(URI uri,int depth) throws Exception{
		StringBuilder messageResponse = new StringBuilder();
		boolean status = false;
		try {


			//Set Current depth ,Initial depth is 20
			currentDepth=depth;
			
			if (depth < 1) {
				//Stop Crawl
				return;
			}
			
			//Evaluate the URI link
			if(siteTree.getPagesVisited().contains(uri)){
				logger.info(uri.getPath()+" has already been visited");
				return;
			}
			else{
				logger.info(uri.getPath()+" has not been visited.Adding to ToVisit List");
				siteTree.getPagesVisited().add(uri);
			}
			
			//Get URI Content. Passing Control to Http Client
			logger.info("Getting URI Content");
			status=clientService.getURIContent(uri, messageResponse);
			
			
			if(status){
				//Parse URI Content and Index Data for search
				//Passing Control to Jerry HTML Parser
				logger.info("Initaite URI Content Extraction and Indexing");
				siteTree.getPagesToVisit().addAll(parserService.parseLinks(uri,messageResponse.toString()));
				logger.info("URI Content has been extracted and indexed");
				//Crawl Net Link in ToVisit List 
				//Decrement Depth by 1
				for(int index=0;index<siteTree.getPagesToVisit().size();index++){
					crawl(siteTree.getPagesToVisit().get(index),depth=depth-1);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	
	/**
	 * Delete Previous Lucene data
	 * @author JOEL,Sharun
	 * */
	private void deleteIndeingData() {
		try {
			String path = System.getProperty("user.dir") + "\\lucene_dat";
			File directory = new File(path);
			if (directory.exists() && directory.isDirectory()) {
				File files[] = directory.listFiles();
				for (File file : files) {
					file.delete();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		
	}

}
