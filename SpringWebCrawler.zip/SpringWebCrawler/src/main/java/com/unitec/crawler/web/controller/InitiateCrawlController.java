/**
 * 
 */
package com.unitec.crawler.web.controller;

import java.net.URI;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.unitec.crawler.app.constants.ApplicationConstants;
import com.unitec.crawler.http.service.intf.SpiderService;
import com.unitec.crawler.index.service.intf.SearchIndex;
import com.unitec.crawler.model.bean.CrawlerModel;
import com.unitec.crawler.model.bean.SiteBean;

/**
 * @author JOEL,Sharun
 *
 */
@Controller
@RequestMapping("/")

public class InitiateCrawlController {

	public static Logger LOG= LoggerFactory.getLogger(InitiateCrawlController.class);

	@Autowired
	public SpiderService spider;
	@Autowired
	public SearchIndex searchService;

	/**
	 * Initial Controller Method
	 * @author JOEL,Sharun
	 *
	 */

	@RequestMapping(method = RequestMethod.GET)
	public String loadOnStartup(ModelMap model) {
		LOG.info("Rerouting to home page");
		try {
			CrawlerModel crawlerModel= new CrawlerModel();
			model.addAttribute("crawlerModel",crawlerModel);		
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "welcome";
	}

	/**
	 * Crawler Controller Method
	 * @author JOEL,Sharun
	 *
	 */

	@RequestMapping(method = RequestMethod.POST, value = "/crawl")
	public String crawl(@ModelAttribute CrawlerModel crawlerModel, Map<String, Object> model) {

		LOG.info("Initiate Crawl Operation for "+crawlerModel.getUri());
		try {
			//Initiate Web Spider and Navigate to search page
			spider.initiateURICrawling(new URI(crawlerModel.getUri()), ApplicationConstants.CRAWL_DEPTH);
			LOG.info("Web Crawl Operation Completed");
			model.put("result", crawlerModel);
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return "search";
	}

	/**
	 * Search Controller Method
	 * @author JOEL,Sharun
	 *
	 */

	@RequestMapping(method = RequestMethod.POST, value = "/find")
	public String search(CrawlerModel crawlerModel, ModelMap model,BindingResult besult) {


		//Initiate search service
		List<SiteBean> siteBeans = searchService.search(crawlerModel.getSearchKey());
		//Populate search result model
		LOG.info("Search Results Size "+siteBeans.size());
		
		model.addAttribute("result", new CrawlerModel());
		model.addAttribute("sites", siteBeans);
		LOG.info("searcher  successful!");
		return "search";
	}
}
