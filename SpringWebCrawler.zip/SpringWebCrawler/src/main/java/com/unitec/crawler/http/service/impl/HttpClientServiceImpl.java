package com.unitec.crawler.http.service.impl;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URI;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.unitec.crawler.http.service.intf.HttpClientService;

/**
 * @author JOEL,Sharun
 *
 */
@Service
public class HttpClientServiceImpl implements HttpClientService{

	private static Logger logger = LoggerFactory
			.getLogger(HttpClientServiceImpl.class);
	
	@Override
	public boolean getURIContent(URI uri, StringBuilder content) throws Exception {
		CloseableHttpClient httpclient = HttpClients.createDefault();
		HttpResponse httpResponse;
		
		try {
			//Check URI Validity
			httpResponse = httpclient.execute(new HttpGet(uri));
			if (200 != httpResponse.getStatusLine().getStatusCode()) {
				logger.error("Invalid URI:" + uri.toString());
				return false;
			}

			InputStream is = httpResponse.getEntity().getContent();

			BufferedReader reader = new BufferedReader(
					new InputStreamReader(is));

			String line;
			while ((line = reader.readLine()) != null) {
				content.append(line);
				logger.info("Content in URI:" + line);
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;		
			}
		return true;
	}

}
