package com.unitec.crawler.model.bean;

public class CrawlerModel {


	private String uri;


	private int depth;
	
	private String searchKey;
	
	private String statusMessage;
	
	public CrawlerModel(String uri, int depth) {
		this.uri = uri;
		this.depth = depth;
	}

	public CrawlerModel() {
	}

	public String getUri() {
		return uri;
	}

	public void setUri(String uri) {
		this.uri = uri;
	}

	public int getDepth() {
		return depth;
	}

	public void setDepth(int depth) {
		this.depth = depth;
	}

	public String getStatusMessage() {
		return statusMessage;
	}

	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}

	public String getSearchKey() {
		return searchKey;
	}

	public void setSearchKey(String searchKey) {
		this.searchKey = searchKey;
	}
	
	
}
