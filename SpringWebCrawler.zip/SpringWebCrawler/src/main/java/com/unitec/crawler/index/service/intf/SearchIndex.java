/**
 * 
 */
package com.unitec.crawler.index.service.intf;

import java.util.List;

import com.unitec.crawler.model.bean.SiteBean;

/**
 * @author JOEL
 *
 */
public interface SearchIndex {

	public List<SiteBean> search(String content);
}
