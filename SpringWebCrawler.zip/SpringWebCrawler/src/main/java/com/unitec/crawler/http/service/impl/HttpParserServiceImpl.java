package com.unitec.crawler.http.service.impl;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.LinkedList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.unitec.crawler.app.constants.ApplicationConstants;
import com.unitec.crawler.http.service.intf.HttpParserService;
import com.unitec.crawler.index.service.intf.LuceneIndexer;

import jodd.jerry.Jerry;
import jodd.jerry.Jerry.JerryParser;
import jodd.jerry.JerryFunction;
import jodd.lagarto.LagartoParser;
import jodd.lagarto.adapter.StripHtmlTagAdapter;
import jodd.lagarto.dom.LagartoDOMBuilder;
import jodd.lagarto.dom.LagartoDOMBuilderTagVisitor;
import jodd.util.StringUtil;

@Service
public class HttpParserServiceImpl  implements HttpParserService{

	private static Logger logger = LoggerFactory.getLogger(HttpParserServiceImpl.class);
	private List<URI> nestedURIs;
	private URI uri;
	
	
	@Autowired
	private LuceneIndexer IndexerService;
	
	
	@Override
	public List<URI> parseLinks(URI uri, String content) {
		this.uri=uri;
		nestedURIs = new LinkedList<URI>();
		//Extract Tet Content From HTML
		extractHtmlTextContent(content);
		if (1 == SpiderServiceImpl.currentDepth) {
			logger.debug("Stop parsing href because current depth is 1.");
		} else {
			getHRefLinks(content);
		}
		
		logger.info("Found (" + nestedURIs.size() + ") links in [" + uri.toString()
		+ "]");

		return nestedURIs;
	}
	
	public void extractHtmlTextContent(String content){
		
		StringBuilder result = new StringBuilder();
		JerryParser jerryParser = Jerry.jerry();

		LagartoDOMBuilder lagartoDOMBuilder = (LagartoDOMBuilder) jerryParser
				.getDOMBuilder();
		//Enable HTML 5 parsing
		lagartoDOMBuilder.enableHtmlMode();
		//Enable Tag Analysis
		LagartoDOMBuilderTagVisitor tagVisitor = new LagartoDOMBuilderTagVisitor(
				lagartoDOMBuilder);
		logger.info("Getting Text Content");

		
		LagartoParser parser = new LagartoParser(content, false);
		
		parser.parse(new StripHtmlTagAdapter(tagVisitor) {
			public void text(CharSequence text) {

				String str = text.toString();
				str = StringUtil.removeChars(str, "\r\n\t\b");
				String noHTMLString = str.replaceAll("\\<.*?\\>", "");
				logger.info("tags removed"+noHTMLString);
				if (noHTMLString.trim().length() != 0) {
					result.append(noHTMLString);
				}
			}

		});
		 
		 
		
		IndexerService.createIndex(this.uri, result.toString());
	}

	public void getHRefLinks(String content) {
		logger.info("getting Links");

		Jerry doc = Jerry.jerry(content);
		doc.$("a").each(new JerryFunction() {
			public Boolean onNode(Jerry $this, int index) {

				URI uri;
				String link = $this.attr("href");
				logger.info("FOUND href!");
				if (null == link || "".equals(link.trim())) {
					logger.info("Blank href!");
					return true;
				}

				if (!link.startsWith(ApplicationConstants.PREFIX_HTTP)
						&& !link.startsWith(ApplicationConstants.PREFIX_HTTPS)
						&& !link.startsWith(ApplicationConstants.PREFIX_SLASH)) {
					logger.info("Not a http href:" + link);
					return true;
				} else if (link.startsWith(ApplicationConstants.PREFIX_SLASH)) {
					link = ApplicationConstants.PREFIX_HTTP + SpiderServiceImpl.URI_HOST
							+ link;
				}

				try {
					uri = new URI(link);
					if (nestedURIs.contains(uri)) {
						logger.info("Already existing href:" + link);
						return true;
					}

					if (!uri.getHost().contains(SpiderServiceImpl.URI_HOST_KEY)) {
						logger.info("Other website href:" + link);
						return true;
					}
					
					if (!SpiderServiceImpl.siteTree.getPagesToVisit().contains(uri)) {
						SpiderServiceImpl.siteTree.getPagesToVisit().add(uri);
						nestedURIs.add(uri);
					}
				} catch (URISyntaxException e) {
					logger.error("URISyntaxException with href:" + link);
					return true;
				}

				return true;
			}
		});
	}

}
