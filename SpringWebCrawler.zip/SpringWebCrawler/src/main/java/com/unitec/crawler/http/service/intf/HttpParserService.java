/**
 * 
 */
package com.unitec.crawler.http.service.intf;

import java.net.URI;
import java.util.List;

/**
 * @author JOEL
 *
 */
public interface HttpParserService {
	
	public List<URI> parseLinks(URI uri, String content);	

}
