/**
 * 
 */
package com.unitec.crawler.index.service.intf;

import java.net.URI;

/**
 * @author JOEL
 *
 */
public interface LuceneIndexer {
	
	public void createIndex(URI uri, String content);	

}
