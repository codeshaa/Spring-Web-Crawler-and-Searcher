/**
 * 
 */
package com.unitec.crawler.app.config;

/**
 * @author JOEL
 *
 */
public class AppTestMain {
	
	

}
