package com.unitec.crawler.http.service.intf;

import java.net.URI;

public interface HttpClientService {

	public boolean getURIContent(URI url,StringBuilder content) throws Exception;

}
